/*
MySQL Data Transfer
Source Host: localhost
Source Database: healthawareness
Target Host: localhost
Target Database: healthawareness
Date: 12/03/2021 18:38:04
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for anxiety
-- ----------------------------
DROP TABLE IF EXISTS `anxiety`;
CREATE TABLE `anxiety` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) NOT NULL,
  `q1ans1` varchar(50) NOT NULL,
  `q1ans2` varchar(50) NOT NULL,
  `q1ans3` varchar(50) NOT NULL,
  `q1ans4` varchar(50) NOT NULL,
  `q1cans` varchar(50) NOT NULL,
  `q2` varchar(50) NOT NULL,
  `q2ans1` varchar(50) NOT NULL,
  `q2ans2` varchar(50) NOT NULL,
  `q2ans3` varchar(50) NOT NULL,
  `q2ans4` varchar(50) NOT NULL,
  `q2cans` varchar(255) NOT NULL,
  `q3` varchar(50) NOT NULL,
  `q3ans1` varchar(50) NOT NULL,
  `q3ans2` varchar(50) NOT NULL,
  `q3ans3` varchar(50) NOT NULL,
  `q3ans4` varchar(50) NOT NULL,
  `q3cans` varchar(50) NOT NULL,
  `q4` varchar(50) NOT NULL,
  `q4ans1` varchar(50) NOT NULL,
  `q4ans2` varchar(50) NOT NULL,
  `q4ans3` varchar(50) NOT NULL,
  `q4ans4` varchar(50) NOT NULL,
  `q4cans` varchar(50) NOT NULL,
  `q5` varchar(50) NOT NULL,
  `q5ans1` varchar(50) NOT NULL,
  `q5ans2` varchar(50) NOT NULL,
  `q5ans3` varchar(50) NOT NULL,
  `q5ans4` varchar(50) NOT NULL,
  `q5cans` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for bipolardisorder
-- ----------------------------
DROP TABLE IF EXISTS `bipolardisorder`;
CREATE TABLE `bipolardisorder` (
  `id` int(50) NOT NULL DEFAULT '0',
  `q1` varchar(50) NOT NULL,
  `q1ans1` varchar(50) NOT NULL,
  `q1ans2` varchar(50) NOT NULL,
  `q1ans3` varchar(50) NOT NULL,
  `q1ans4` varchar(50) NOT NULL,
  `q1cans` varchar(50) NOT NULL,
  `q2` varchar(50) NOT NULL,
  `q2ans1` varchar(50) NOT NULL,
  `q2ans2` varchar(50) NOT NULL,
  `q2ans3` varchar(50) NOT NULL,
  `q2ans4` varchar(50) NOT NULL,
  `q2cans` varchar(255) NOT NULL,
  `q3` varchar(50) NOT NULL,
  `q3ans1` varchar(50) NOT NULL,
  `q3ans2` varchar(50) NOT NULL,
  `q3ans3` varchar(50) NOT NULL,
  `q3ans4` varchar(50) NOT NULL,
  `q3cans` varchar(50) NOT NULL,
  `q4` varchar(50) NOT NULL,
  `q4ans1` varchar(50) NOT NULL,
  `q4ans2` varchar(50) NOT NULL,
  `q4ans3` varchar(50) NOT NULL,
  `q4ans4` varchar(50) NOT NULL,
  `q4cans` varchar(50) NOT NULL,
  `q5` varchar(50) NOT NULL,
  `q5ans1` varchar(50) NOT NULL,
  `q5ans2` varchar(50) NOT NULL,
  `q5ans3` varchar(50) NOT NULL,
  `q5ans4` varchar(50) NOT NULL,
  `q5cans` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for blogs
-- ----------------------------
DROP TABLE IF EXISTS `blogs`;
CREATE TABLE `blogs` (
  `disorder` varchar(26) NOT NULL,
  `blogcontent` varchar(100) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for depression
-- ----------------------------
DROP TABLE IF EXISTS `depression`;
CREATE TABLE `depression` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) NOT NULL,
  `q1ans1` varchar(50) NOT NULL,
  `q1ans2` varchar(50) NOT NULL,
  `q1ans3` varchar(50) NOT NULL,
  `q1ans4` varchar(50) NOT NULL,
  `q1cans` varchar(50) NOT NULL,
  `q2` varchar(50) NOT NULL,
  `q2ans1` varchar(50) NOT NULL,
  `q2ans2` varchar(50) NOT NULL,
  `q2ans3` varchar(50) NOT NULL,
  `q2ans4` varchar(50) NOT NULL,
  `q2cans` varchar(255) NOT NULL,
  `q3` varchar(50) NOT NULL,
  `q3ans1` varchar(50) NOT NULL,
  `q3ans2` varchar(50) NOT NULL,
  `q3ans3` varchar(50) NOT NULL,
  `q3ans4` varchar(50) NOT NULL,
  `q3cans` varchar(50) NOT NULL,
  `q4` varchar(50) NOT NULL,
  `q4ans1` varchar(50) NOT NULL,
  `q4ans2` varchar(50) NOT NULL,
  `q4ans3` varchar(50) NOT NULL,
  `q4ans4` varchar(50) NOT NULL,
  `q4cans` varchar(50) NOT NULL,
  `q5` varchar(50) NOT NULL,
  `q5ans1` varchar(50) NOT NULL,
  `q5ans2` varchar(50) NOT NULL,
  `q5ans3` varchar(50) NOT NULL,
  `q5ans4` varchar(50) NOT NULL,
  `q5cans` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for diseases
-- ----------------------------
DROP TABLE IF EXISTS `diseases`;
CREATE TABLE `diseases` (
  `disease` varchar(60) NOT NULL,
  `description` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for doctor
-- ----------------------------
DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor` (
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `workingarea` varchar(50) NOT NULL,
  `hospital` varchar(50) NOT NULL,
  `experience` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for freetime
-- ----------------------------
DROP TABLE IF EXISTS `freetime`;
CREATE TABLE `freetime` (
  `doctorname` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `experience` varchar(50) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for ocd
-- ----------------------------
DROP TABLE IF EXISTS `ocd`;
CREATE TABLE `ocd` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) NOT NULL,
  `q1ans1` varchar(50) NOT NULL,
  `q1ans2` varchar(50) NOT NULL,
  `q1ans3` varchar(50) NOT NULL,
  `q1ans4` varchar(50) NOT NULL,
  `q1cans` varchar(50) NOT NULL,
  `q2` varchar(50) NOT NULL,
  `q2ans1` varchar(50) NOT NULL,
  `q2ans2` varchar(50) NOT NULL,
  `q2ans3` varchar(50) NOT NULL,
  `q2ans4` varchar(50) NOT NULL,
  `q2cans` varchar(255) NOT NULL,
  `q3` varchar(50) NOT NULL,
  `q3ans1` varchar(50) NOT NULL,
  `q3ans2` varchar(50) NOT NULL,
  `q3ans3` varchar(50) NOT NULL,
  `q3ans4` varchar(50) NOT NULL,
  `q3cans` varchar(50) NOT NULL,
  `q4` varchar(50) NOT NULL,
  `q4ans1` varchar(50) NOT NULL,
  `q4ans2` varchar(50) NOT NULL,
  `q4ans3` varchar(50) NOT NULL,
  `q4ans4` varchar(50) NOT NULL,
  `q4cans` varchar(50) NOT NULL,
  `q5` varchar(50) NOT NULL,
  `q5ans1` varchar(50) NOT NULL,
  `q5ans2` varchar(50) NOT NULL,
  `q5ans3` varchar(50) NOT NULL,
  `q5ans4` varchar(50) NOT NULL,
  `q5cans` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for posttraumaticstress
-- ----------------------------
DROP TABLE IF EXISTS `posttraumaticstress`;
CREATE TABLE `posttraumaticstress` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) NOT NULL,
  `q1ans1` varchar(50) NOT NULL,
  `q1ans2` varchar(50) NOT NULL,
  `q1ans3` varchar(50) NOT NULL,
  `q1ans4` varchar(50) NOT NULL,
  `q1cans` varchar(50) NOT NULL,
  `q2` varchar(50) NOT NULL,
  `q2ans1` varchar(50) NOT NULL,
  `q2ans2` varchar(50) NOT NULL,
  `q2ans3` varchar(50) NOT NULL,
  `q2ans4` varchar(50) NOT NULL,
  `q2cans` varchar(255) NOT NULL,
  `q3` varchar(50) NOT NULL,
  `q3ans1` varchar(50) NOT NULL,
  `q3ans2` varchar(50) NOT NULL,
  `q3ans3` varchar(50) NOT NULL,
  `q3ans4` varchar(50) NOT NULL,
  `q3cans` varchar(50) NOT NULL,
  `q4` varchar(50) NOT NULL,
  `q4ans1` varchar(50) NOT NULL,
  `q4ans2` varchar(50) NOT NULL,
  `q4ans3` varchar(50) NOT NULL,
  `q4ans4` varchar(50) NOT NULL,
  `q4cans` varchar(50) NOT NULL,
  `q5` varchar(50) NOT NULL,
  `q5ans1` varchar(50) NOT NULL,
  `q5ans2` varchar(50) NOT NULL,
  `q5ans3` varchar(50) NOT NULL,
  `q5ans4` varchar(50) NOT NULL,
  `q5cans` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for schizophrenia
-- ----------------------------
DROP TABLE IF EXISTS `schizophrenia`;
CREATE TABLE `schizophrenia` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) NOT NULL,
  `q1ans1` varchar(50) NOT NULL,
  `q1ans2` varchar(50) NOT NULL,
  `q1ans3` varchar(50) NOT NULL,
  `q1ans4` varchar(50) NOT NULL,
  `q1cans` varchar(50) NOT NULL,
  `q2` varchar(50) NOT NULL,
  `q2ans1` varchar(50) NOT NULL,
  `q2ans2` varchar(50) NOT NULL,
  `q2ans3` varchar(50) NOT NULL,
  `q2ans4` varchar(50) NOT NULL,
  `q2cans` varchar(255) NOT NULL,
  `q3` varchar(50) NOT NULL,
  `q3ans1` varchar(50) NOT NULL,
  `q3ans2` varchar(50) NOT NULL,
  `q3ans3` varchar(50) NOT NULL,
  `q3ans4` varchar(50) NOT NULL,
  `q3cans` varchar(50) NOT NULL,
  `q4` varchar(50) NOT NULL,
  `q4ans1` varchar(50) NOT NULL,
  `q4ans2` varchar(50) NOT NULL,
  `q4ans3` varchar(50) NOT NULL,
  `q4ans4` varchar(50) NOT NULL,
  `q4cans` varchar(50) NOT NULL,
  `q5` varchar(50) NOT NULL,
  `q5ans1` varchar(50) NOT NULL,
  `q5ans2` varchar(50) NOT NULL,
  `q5ans3` varchar(50) NOT NULL,
  `q5ans4` varchar(50) NOT NULL,
  `q5cans` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for user1
-- ----------------------------
DROP TABLE IF EXISTS `user1`;
CREATE TABLE `user1` (
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for userfeedback
-- ----------------------------
DROP TABLE IF EXISTS `userfeedback`;
CREATE TABLE `userfeedback` (
  `username` varchar(50) NOT NULL,
  `doctorname` varchar(50) NOT NULL,
  `rating` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `bipolardisorder` VALUES ('2', 'dfgdfg', 'dfgdfg', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'dfgdfg', 'dfgdfg', 'dfgdfg', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'dfgdfg', 'sdfsdf', 'sdfsd', 'sdfdsf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsd', 'sdfsd', 'sdfdsf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'fdsdf', 'sdfsdf');
INSERT INTO `bipolardisorder` VALUES ('3', 'sfdsd', 'asdasd', 'adsad', 'asdasd', 'asdasd', 'asdasd', 'asdas', 'asdsas', 'asdsad', 'asdasd', 'asdasd', 'adas', 'asdsad', 'asdas', 'asdasd', 'asdasd', 'asdsa', 'asdasd', 'asdasd', 'asdsad', 'asdasd', 'asdas', 'asdasd', 'asdsad', 'asdsad', 'asdas', 'adsasd', 'asdasd', 'asdasd', 'asdsad');
INSERT INTO `bipolardisorder` VALUES ('4', 'sdfsdf', 'sdfds', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'dsfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf');
INSERT INTO `blogs` VALUES ('OCD', 'this is the main content of the application', '2');
INSERT INTO `depression` VALUES ('1', 'q1', 'q1ans1', 'q1ans2', 'q1and3', 'q1ans4', 'q1ans2', 'q2', 'q2ans1', 'q2ans2', 'q2ans3', 'q2ans4', 'q2ans1', 'q3', 'q3ans1', 'q3ans2', 'q3ans3', 'q3ans4', 'q3qns3', 'q4', 'q4ans1', 'q4ans2', 'q4ans3', 'q4ans4', 'q4ans1', 'q5', 'q5ans1', 'q5ans2', 'q5ans3', 'q5ans4', 'q5ans1');
INSERT INTO `diseases` VALUES ('Anxiety', 'This is the data relate to anxiety');
INSERT INTO `doctor` VALUES ('abc', 'abc', 'abc', 'abc@gmail.com', '1234567890', '21', 'abc', 'jkk', '12', '10', 'female\"');
INSERT INTO `freetime` VALUES ('abc', '12-03-2021', '2pm-3pm', '12', '1');
INSERT INTO `ocd` VALUES ('2', 'dfgdfg', 'dfgdfg', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'dfgdfg', 'dfgdfg', 'dfgdfg', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'dfgdfg', 'sdfsdf', 'sdfsd', 'sdfdsf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsd', 'sdfsd', 'sdfdsf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'fdsdf', 'sdfsdf');
INSERT INTO `ocd` VALUES ('3', 'sfdsd', 'asdasd', 'adsad', 'asdasd', 'asdasd', 'asdasd', 'asdas', 'asdsas', 'asdsad', 'asdasd', 'asdasd', 'adas', 'asdsad', 'asdas', 'asdasd', 'asdasd', 'asdsa', 'asdasd', 'asdasd', 'asdsad', 'asdasd', 'asdas', 'asdasd', 'asdsad', 'asdsad', 'asdas', 'adsasd', 'asdasd', 'asdasd', 'asdsad');
INSERT INTO `ocd` VALUES ('4', 'what is jvm', 'java virtual machine', 'may be', 'not correct', 'none', 'java virtual machine', 'what i os', 'one time system', 'operating system', 'my only system', 'none', 'operating system', 'what is servlet', 'it is web', 'it is db', 'it is webtechnologly', 'it is serverside programme', 'it is serverside programme', 'what is oralce', 'it is db', 'it is os', 'it is web', 'it is editor', 'it is db', 'what is ide', 'it is editor', 'it is os ', 'it is eclipse', 'integrated environment', 'integrated environment');
INSERT INTO `posttraumaticstress` VALUES ('2', 'dfgdfg', 'dfgdfg', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'dfgdfg', 'dfgdfg', 'dfgdfg', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'dfgdfg', 'sdfsdf', 'sdfsd', 'sdfdsf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsd', 'sdfsd', 'sdfdsf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'fdsdf', 'sdfsdf');
INSERT INTO `posttraumaticstress` VALUES ('3', 'sfdsd', 'asdasd', 'adsad', 'asdasd', 'asdasd', 'asdasd', 'asdas', 'asdsas', 'asdsad', 'asdasd', 'asdasd', 'adas', 'asdsad', 'asdas', 'asdasd', 'asdasd', 'asdsa', 'asdasd', 'asdasd', 'asdsad', 'asdasd', 'asdas', 'asdasd', 'asdsad', 'asdsad', 'asdas', 'adsasd', 'asdasd', 'asdasd', 'asdsad');
INSERT INTO `posttraumaticstress` VALUES ('4', 'sdfsdf', 'sdfds', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'dsfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfdsf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf');
INSERT INTO `student` VALUES ('mahesh', 'mahesh', 'mahesh', '7569455919', 'male\"', '21', 'mahesh@gmail.com');
INSERT INTO `user1` VALUES ('chandra', 'chandra', 'chandra', '7569455919', 'male\"', '21', 'chandra.myhome@gmail.com');
INSERT INTO `userfeedback` VALUES ('chandra', 'abc', '4');
